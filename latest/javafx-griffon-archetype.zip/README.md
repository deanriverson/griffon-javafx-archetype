Griffon JavaFX Archetype
========================

An archetype that lets you create a new Griffon project as a JavaFX 2.0
application.

*This plugin is highly experimental*
